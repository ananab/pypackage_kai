from .sd import standard_deviation
from .sd import standard_error
