from .sdse import standard_deviation
from .sdse import standard_error
